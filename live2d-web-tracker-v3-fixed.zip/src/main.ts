import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";
import { unzipSync } from "fflate";
import { LAppDelegate } from "./lappdelegate";
import { ParameterMapping, TrackingSource } from "./lappmodel";

type Settings = {
  sensitivity: number;
  smoothing: number;
  background: "transparent" | "green" | "blue" | "custom";
  customColor: string;
  mappings: Record<string, ParameterMapping>;
};
const KEY="live2d-web-tracker-v3";
const defaults: Settings={sensitivity:1,smoothing:.7,background:"transparent",customColor:"#202020",mappings:{}};
let settings: Settings=(()=>{try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)??"{}")}}catch{return {...defaults}}})();
const save=()=>localStorage.setItem(KEY,JSON.stringify(settings));

const stage=document.querySelector<HTMLDivElement>("#stage")!;
const status=document.querySelector<HTMLDivElement>("#status")!;
const camera=document.querySelector<HTMLVideoElement>("#camera")!;
const cameraBtn=document.querySelector<HTMLButtonElement>("#cameraBtn")!;
const obsBtn=document.querySelector<HTMLButtonElement>("#obsBtn")!;
const sensitivity=document.querySelector<HTMLInputElement>("#sensitivity")!;
const smoothing=document.querySelector<HTMLInputElement>("#smoothing")!;
const sensitivityValue=document.querySelector<HTMLOutputElement>("#sensitivityValue")!;
const smoothingValue=document.querySelector<HTMLOutputElement>("#smoothingValue")!;
const customColor=document.querySelector<HTMLInputElement>("#customColor")!;
const trackingDot=document.querySelector<HTMLSpanElement>("#trackingDot")!;
const trackingText=document.querySelector<HTMLSpanElement>("#trackingText")!;
const modelInput=document.querySelector<HTMLInputElement>("#modelInput")!;
const mappingList=document.querySelector<HTMLDivElement>("#mappingList")!;
const mappingSearch=document.querySelector<HTMLInputElement>("#mappingSearch")!;
const mappingStatus=document.querySelector<HTMLDivElement>("#mappingStatus")!;

sensitivity.value=String(settings.sensitivity); smoothing.value=String(settings.smoothing); customColor.value=settings.customColor;
sensitivityValue.value=settings.sensitivity.toFixed(2); smoothingValue.value=settings.smoothing.toFixed(2);

function setBackground(v:Settings["background"]){settings.background=v;save();stage.className=`stage ${v}`;stage.style.background=v==="custom"?settings.customColor:"";document.querySelectorAll<HTMLButtonElement>("[data-bg]").forEach(b=>b.classList.toggle("selected",b.dataset.bg===v));}
setBackground(settings.background);
document.querySelectorAll<HTMLButtonElement>("[data-bg]").forEach(b=>b.onclick=()=>setBackground(b.dataset.bg as Settings["background"]));
customColor.oninput=()=>{settings.customColor=customColor.value;if(settings.background==="custom")stage.style.background=settings.customColor;save();};
sensitivity.oninput=()=>{settings.sensitivity=Number(sensitivity.value);sensitivityValue.value=settings.sensitivity.toFixed(2);save();};
smoothing.oninput=()=>{settings.smoothing=Number(smoothing.value);smoothingValue.value=settings.smoothing.toFixed(2);save();};
obsBtn.onclick=()=>document.body.classList.toggle("obs");

const delegate=LAppDelegate.getInstance();
delegate.initialize();
const canvas=delegate.getCanvas(); if(!canvas) throw new Error("Cubism canvas initialization failed");
stage.prepend(canvas); delegate.run();

let face:FaceLandmarker|null=null, stream:MediaStream|null=null, running=false,lastVideoTime=-1;
let smooth={x:0,y:0,z:0,eye:1,mouth:0};

async function initFace(){
 if(face)return face;
 status.textContent="顔トラッキングモデルを読み込み中…";
 const vision=await FilesetResolver.forVisionTasks("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm");
 face=await FaceLandmarker.createFromOptions(vision,{baseOptions:{modelAssetPath:"https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",delegate:"GPU"},runningMode:"VIDEO",numFaces:1,outputFaceBlendshapes:false,outputFacialTransformationMatrixes:false});
 return face;
}
const dist=(a:{x:number,y:number},b:{x:number,y:number})=>Math.hypot(a.x-b.x,a.y-b.y);
const clamp=(v:number,a:number,b:number)=>Math.max(a,Math.min(b,v));
const lerp=(a:number,b:number,t:number)=>a+(b-a)*t;

async function trackFrame(now:number){
 if(!running||!face)return;
 if(camera.readyState>=2&&camera.currentTime!==lastVideoTime){
  const result=face.detectForVideo(camera,now);lastVideoTime=camera.currentTime;
  const lm=result.faceLandmarks?.[0],model=delegate.getCurrentModel();
  if(lm&&model){
   const le=lm[33],re=lm[263],nose=lm[1],chin=lm[152],forehead=lm[10],eyeMid={x:(le.x+re.x)/2,y:(le.y+re.y)/2},eyeDist=dist(le,re)||.2;
   const roll=Math.atan2(re.y-le.y,re.x-le.x)*180/Math.PI;
   const yaw=clamp((nose.x-eyeMid.x)/eyeDist*75*settings.sensitivity,-30,30);
   const faceH=Math.max(.2,dist(forehead,chin));
   const pitch=clamp(((nose.y-eyeMid.y)/faceH-.28)*115*settings.sensitivity,-30,30);
   const mouthTop=lm[13],mouthBottom=lm[14],mouthLeft=lm[61],mouthRight=lm[291];
   const mouth=clamp((dist(mouthTop,mouthBottom)/(dist(mouthLeft,mouthRight)||.2)-.12)*8,0,1);
   const blinkL=clamp(1-(dist(lm[159],lm[145])/.055),0,1),blinkR=clamp(1-(dist(lm[386],lm[374])/.055),0,1),eyeOpen=1-(blinkL+blinkR)/2;
   const a=1-settings.smoothing;
   smooth.x=lerp(smooth.x,yaw,a);smooth.y=lerp(smooth.y,pitch,a);smooth.z=lerp(smooth.z,-roll,a);smooth.eye=lerp(smooth.eye,eyeOpen,a);smooth.mouth=lerp(smooth.mouth,mouth,a);
   model.setTrackingValues(smooth.x,smooth.y,smooth.z,smooth.eye,smooth.mouth);
   delegate.applyParameterMappings(settings.mappings);
   trackingDot.style.background="#45d483";trackingText.textContent="顔検出中";mappingStatus.textContent="トラッキング値をマッピングへ反映中";
   status.textContent=`Tracking  X ${smooth.x.toFixed(1)}°  Y ${smooth.y.toFixed(1)}°  Z ${smooth.z.toFixed(1)}°`;
  }else{trackingText.textContent="顔未検出";mappingStatus.textContent="顔が検出されるとマッピングが動きます";}
 }
 requestAnimationFrame(trackFrame);
}

cameraBtn.onclick=async()=>{
 if(running){stream?.getTracks().forEach(t=>t.stop());stream=null;running=false;cameraBtn.textContent="カメラ開始";status.textContent="カメラ停止";trackingText.textContent="未接続";return;}
 try{await initFace();stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});camera.srcObject=stream;await camera.play();running=true;cameraBtn.textContent="カメラ停止";status.textContent="顔トラッキング開始";requestAnimationFrame(trackFrame);}
 catch(e){console.error(e);status.textContent="カメラまたはトラッキングの初期化に失敗しました";}
};

// ---- Arbitrary model loader ------------------------------------------------
// Supports a .zip containing a model3.json and all referenced assets.
// Also supports selecting a model3.json plus its asset folder via the
// directory picker. The model3.json is rewritten to use blob URLs, allowing
// the existing Cubism sample loader to resolve every referenced asset.
function norm(p:string){return p.replaceAll("\\","/").replace(/^\.\/+/,"").replace(/^\/+/,"");}
function findAsset(files:Map<string,Blob>, wanted:string){
 const w=norm(wanted);
 if(files.has(w))return files.get(w)!;
 const matches=[...files.entries()].filter(([k])=>norm(k).endsWith("/"+w)||norm(k)===w);
 return matches[0]?.[1]??null;
}
function rewriteRefs(value:any,files:Map<string,Blob>,urls:Map<string,string>):any{
 if(Array.isArray(value))return value.map(v=>rewriteRefs(v,files,urls));
 if(value&&typeof value==="object"){const out:any={};for(const [k,v] of Object.entries(value))out[k]=rewriteRefs(v,files,urls);return out;}
 if(typeof value==="string"){
  const b=findAsset(files,value);
  if(b){
   const key=[...files.entries()].find(([,x])=>x===b)?.[0]??value;
   if(!urls.has(key))urls.set(key,URL.createObjectURL(b));
   return urls.get(key)!;
  }
 }
 return value;
}
function loadBundle(modelJson: string, files:Map<string,Blob>, label:string){
 try{
  const original=JSON.parse(modelJson),urls=new Map<string,string>();
  const rewritten=rewriteRefs(original.FileReferences?{...original,FileReferences:rewriteRefs(original.FileReferences,files,urls)}:original,files,urls);
  const modelBlob=new Blob([JSON.stringify(rewritten)],{type:"application/json"});
  const modelUrl=URL.createObjectURL(modelBlob);
  delegate.loadModelFromPath("",modelUrl);
  status.textContent=`モデル読み込み中: ${label}`;
  setTimeout(renderMappings,500);
 }catch(e){console.error(e);status.textContent="モデルの読み込みに失敗しました";}
}
async function readZip(file:File){
 const bytes=new Uint8Array(await file.arrayBuffer()),unz=unzipSync(bytes),files=new Map<string,Blob>();
 for(const [name,data] of Object.entries(unz)) if(data)files.set(norm(name),new Blob([data]));
 const entry=[...files.entries()].find(([n])=>n.toLowerCase().endsWith(".model3.json"));
 if(!entry)throw new Error(".model3.json がZIP内にありません");
 loadBundle(await entry[1].text(),files,entry[0]);
}
async function readDirectory(fileList:FileList){
 const files=new Map<string,Blob>();let modelFile:File|null=null;
 for(const f of [...fileList]){const rel=norm((f as any).webkitRelativePath||f.name);files.set(rel,f);if(f.name.toLowerCase().endsWith(".model3.json"))modelFile=f;}
 if(!modelFile)throw new Error("選択フォルダに.model3.jsonがありません");
 loadBundle(await modelFile.text(),files,modelFile.name);
}
modelInput.onchange=async()=>{
 const files=modelInput.files;if(!files?.length)return;
 try{
  const first=files[0];
  if(first.name.toLowerCase().endsWith(".zip"))await readZip(first);else await readDirectory(files);
 }catch(e){console.error(e);status.textContent=e instanceof Error?e.message:"モデル読み込みエラー";}
};

// ---- Parameter mapping UI --------------------------------------------------
const sourceLabels:Record<string,string>={none:"未割当",angleX:"顔 X (Yaw)",angleY:"顔 Y (Pitch)",angleZ:"顔 Z (Roll)",eyeOpen:"目の開閉",mouthOpen:"口の開閉"};
function renderMappings(){
 const defs=delegate.getParameterDefinitions();
 if(!defs.length){mappingList.innerHTML='<div class="hint">モデルの読み込み完了後にパラメータが表示されます。</div>';return;}
 const q=mappingSearch.value.toLowerCase();
 const visible=defs.filter(d=>d.id.toLowerCase().includes(q));
 mappingList.innerHTML="";
 for(const d of visible){
  const current=settings.mappings[d.id]??{source:"none",enabled:false,invert:false,gain:1,offset:0};
  const row=document.createElement("div");row.className="mapping-row";
  row.innerHTML=`<div class="mapping-id"><strong>${d.id}</strong><span>${d.min.toFixed(2)} … ${d.max.toFixed(2)}</span></div>
  <select class="map-source">${Object.entries(sourceLabels).map(([k,v])=>`<option value="${k}" ${current.source===k?"selected":""}>${v}</option>`).join("")}</select>
  <label class="mini"><input type="checkbox" class="map-enabled" ${current.enabled?"checked":""}> 有効</label>
  <label class="mini">反転 <input type="checkbox" class="map-invert" ${current.invert?"checked":""}></label>
  <label class="mini">倍率 <input type="number" class="map-gain" step=".1" min="0" max="5" value="${current.gain}"></label>
  <label class="mini">オフセット <input type="number" class="map-offset" step=".05" value="${current.offset}"></label>`;
  const saveRow=()=>{
   const source=(row.querySelector(".map-source") as HTMLSelectElement).value as TrackingSource|"none";
   settings.mappings[d.id]={source,enabled:(row.querySelector(".map-enabled") as HTMLInputElement).checked,invert:(row.querySelector(".map-invert") as HTMLInputElement).checked,gain:Number((row.querySelector(".map-gain") as HTMLInputElement).value)||0,offset:Number((row.querySelector(".map-offset") as HTMLInputElement).value)||0};save();
  };
  row.querySelectorAll("select,input").forEach(el=>el.addEventListener("change",saveRow));
  mappingList.appendChild(row);
 }
 mappingStatus.textContent=`${defs.length} パラメータ / ${visible.length} 表示`;
}
mappingSearch.oninput=renderMappings;
setInterval(renderMappings,1500);
setTimeout(renderMappings,1000);
