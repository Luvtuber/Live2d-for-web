import { defineConfig } from "vite";
import path from "node:path";

export default defineConfig({
  server: { host: true, port: 5173 },
  resolve: {
    alias: { "@framework": path.resolve(__dirname, "Framework/src") }
  },
  build: { target: "es2020", sourcemap: false }
});