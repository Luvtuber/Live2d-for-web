# Live2D Web Tracker v0.3

## Added
- Load arbitrary Live2D model bundles from a ZIP in the browser.
- Load an entire model directory using the browser directory picker.
- Automatically finds `.model3.json`.
- Rewrites referenced assets to browser Blob URLs, so `.moc3`, textures, physics, pose, expressions and motions can be loaded without a server.
- Dynamic parameter list from the loaded Cubism model.
- Per-parameter mapping GUI:
  - source: face X/Y/Z, eye open, mouth open
  - enable
  - invert
  - gain
  - offset
- Mapping settings persist in localStorage.
- Existing tracking, background and OBS mode remain.

## Run
npm install
npm run dev

## Notes
The directory picker is best supported by Chromium-based browsers. ZIP upload is recommended for portability.
The browser still needs the Cubism Core runtime distributed with the SDK.
